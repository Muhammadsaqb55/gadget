import React from 'react';
import logo from './assets/images/logo.png';
import './App.css';
import { Link } from 'react-router-dom';
import { BrowserRouter as Router, Route, Routes,Switch, useLocation} from 'react-router-dom';
function Devices() {
  const location = useLocation(); // Use useLocation to access the current location

      return (
        <div className="main-wrapper" style={{paddingLeft: '50px',paddingRight: '50px'}}>
        <section className="section home-banner row-middle">
          <div>&nbsp;</div>
          <div className="container">
            <div className="col-md-12">
              <div className="row">
                <div className="col-md-3 mt-4">
                  <div className="search-right banner-content-o desktop-view">
                    <form className="form" name="store" id="store" method="post" action="#">
                      <div className="form-inner">
                        <div className="input-group">
                          <input type="email" className="form-controls" placeholder="Browse Other Devices" />
                          <button className="btn btn-primary sub-btn" type="submit">
                          &nbsp;Search &nbsp; <span><img src="assets/images/search.png" alt="" /></span>
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div className="search-right banner-content-m mobile-view">
                    <form className="form" name="store" id="store" method="post" action="#">
                      <div className="form-inner">
                        <div className="input-group">
                          <input type="email" className="form-controls" placeholder="Browse Other Devices" />
                          <button className="btn btn-primary sub-btn" type="submit">
                            Search &nbsp; &nbsp; &nbsp;<span><img src="assets/images/search.png" alt="" /></span>
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div className="browse-btnx" style={{ borderRadius: '20px !important', textAlign: 'right', fontSize: '11px' }}>
                    <a href="#">Browse Other Brands</a>
                  </div>
                  <div className="inner-left" style={{ backgroundColor: 'rgba(255, 238, 205, 0.50)', borderRadius: '30px', padding: '20px' }}>
                    <h4 className="text-center">Apple iPhone 14 Pro Max </h4>
                    <div className="compare-itemx freelance-count aos mx-auto" style={{ textAlign: 'center',background: 'none !important' }}>
                      <div className="feature-icon" style={{ backgroundColor: '#008ED6', borderRadius: '10px 10px 0px 0px' }}>
                        <img src="assets/images/iphone.png" className="img-fluid" alt="" />
                      </div>
                      <div className='pt-3' style={{ backgroundColor: '#fff', height: 'auto !important', borderRadius: '0px 0px 30px 30px' }}>
                        <div className="row">
                          <div className="col-md-6">
                            <h6><b>Condition</b></h6>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone" style={{border:'2px solid rgba(249, 107, 7, 1)'}}>Good</button></a></div>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone" >Poor</button></a></div>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone">Broken</button></a></div>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone">New</button></a></div>
                          </div>
                          <div className="col-md-6">
                            <h6><b>Capacity</b></h6>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone" style={{border:'2px solid rgba(249, 107, 7, 1)'}}>64GB</button></a></div>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone">128GB</button></a></div>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone">256GB</button></a></div>
                            <div className="m-2"><a href="" className=""><button className="specx-btn-iphone">512GB</button></a></div>
                          </div>
                        </div>
                        <div className="selector-div">
                          <div className="form-group">
                            <label className=""><b>Network</b></label><br />
                            <select name="" id="" style={{ color:'color: var(--inactive-color, #A0A4A8);',padding: '5px 40px', borderRadius: '15px', border: '1px solid rgba(249, 107, 7, 1)', background: 'rgba(0, 142, 214, 0.17)', outline: 'none' }}>
                              <option value="" style={{ color:'color: var(--inactive-color, #A0A4A8);'}}>Unlocked</option>
                              <option value="">1</option>
                              <option value="">1</option>
                            </select>
                          </div>
                        </div>
                        <div className="inner_p p-1" style={{ textAlign: 'left !important' ,paddingLeft: '40px !important'}}>
                          <h6><b>What counts as good?</b></h6>
                          <span className="text-muted" style={{ paddingBottom: '10px'  }}>
                            <p className='what-coun-good-p'>To receive the full quoted price your device</p>
                            <p className='what-coun-good-p'>must power on, show only minor signs of</p>
                            <p className='what-coun-good-p'>use, and have both fully functional</p>
                            <p className='what-coun-good-p'>hardware and software. Check the</p>
                            <p className='what-coun-good-p'>recycler's terms for full details.</p>
                            </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-9 mt-4">
                  <div className="col-md-12 col-sm-12 col-12">
                  <div className="inner-data" style={{ backgroundColor: 'rgba(255, 238, 205, 0.50)', paddingLeft: '50px', paddingRight: '50px', borderRadius: '10px', padding: '0px 20px 20px 20px', alignContent: 'middle' }}>
                    <div className="mb-2" style={{ backgroundImage: 'url(assets/images/bg-blue.png)', backgroundRepeat: 'no-repeat', width: '100%', height: '60px' }}>
                      <h3 className="pt-2"><b> &nbsp; &nbsp; &nbsp; &nbsp;Recommended Offer</b></h3>
                    </div>
                    <div className="row">
                      <div className="col-md-5 col-sm-5 col-5" style={{ padding: '10px' }}>
                        <img src="assets/images/fone-bucks.png" alt=""  style={{ width: '100%' }} />
                        <div className="rating-stars text-center">
                          <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                        </div>
                      </div>
                      <div className="col-md-3 col-sm-3 col-3" style={{ padding: '10px', textAlign: 'center', borderLeft: '2px solid rgba(249, 107, 7, 1)' }}>
                        <h1 className="mt-4">$100</h1>
                      </div>
                      <div className="col-md-4 col-sm-4 col-4" style={{ textAlign: 'center', borderLeft: '2px solid rgba(249, 107, 7, 1)' }}>
                      <div style={{ marginTop:'60px' }}>
                           <a href="/checkout" className="mt-4" style={{ background: '#008ED6', borderRadius: '5px', border: '0px', color: '#fff', padding: '7px 20px'}}><b>Sell Now</b></a>
                           </div>
                      </div>
                    </div>
                  </div>
                  </div>
                  <div>&nbsp;</div>
                  <div className="table p-3" style={{overflow: 'auto', backgroundColor: 'rgba(255, 238, 205, 0.50)', paddingLeft: '50px', paddingRight: '50px', borderRadius: '10px', padding: '0px 20px 20px 20px', alignContent: 'middle' }}>
                    <table style={{ fontSize: '13px', textAlign: 'center' }}>
                      <tr style={{ background: 'rgba(255, 176, 95, 1)' }}>
                        <th>Recycler</th>
                        <th>Price</th>
                        <th>Freepost</th>
                        <th>Payment Method</th>
                        <th>Pay Period</th>
                        <th>Sell Now</th>
                      </tr>
                      <tr>
                        <td>
                          <img src="assets/images/fonbucks.png" alt="" />
                          <div className="rating-stars text-center mt-1">
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          </div>
                        </td>
                        <td><b>$100</b></td>
                        <td><img src="assets/images/green-tick.png" alt="" /></td>
                        <td>
                          <b>
                            <span>Bank Transfer</span><br />
                            <span><img src="assets/images/paypal.png" alt="" /><br /></span>
                            <span>Cheque</span><br />
                           
                          </b>
                        </td>
                        <td><b>Sameday</b></td>
                        <td>
                          <button className="mt-4" style={{ background: '#008ED6', borderRadius: '5px', border: '0px', color: '#fff', padding: '7px 3px' }}><b>Sell Now</b></button>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <img src="assets/images/envire.png" alt="" />
                          <div className="rating-stars text-center mt-1">
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          </div>
                        </td>
                        <td><b>$100</b></td>
                        <td><img src="assets/images/green-tick.png" alt="" /></td>
                        <td>
                          <b>
                            <span>Bank Transfer</span><br />
                            <span><img src="assets/images/paypal.png" alt="" /><br /></span>
                            <span>Cheque</span><br />
                           
                          </b>
                        </td>
                        <td><b>Sameday</b></td>
                        <td>
                          <button className="mt-4" style={{ background: '#008ED6', borderRadius: '5px', border: '0px', color: '#fff', padding: '7px 3px' }}><b>Sell Now</b></button>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <img src="assets/images/uber.png" alt="" />
                          <div className="rating-stars text-center mt-1">
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                          </div>
                        </td>
                        <td><b>$100</b></td>
                        <td><img src="assets/images/green-tick.png" alt="" /></td>
                        <td>
                          <b>
                            <span>Bank Transfer</span><br />
                            <span><img src="assets/images/paypal.png" alt="" /><br /></span>
                            <span>Cheque</span><br />
                           
                          </b>
                        </td>
                        <td><b>Sameday</b></td>
                        <td>
                          <button className="mt-4" style={{ background: '#008ED6', borderRadius: '5px', border: '0px', color: '#fff', padding: '7px 3px' }}><b>Sell Now</b></button>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <img src="assets/images/music.png" alt="" />
                          <div className="rating-stars text-center mt-1">
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)' }}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)'}}><i className="fa fa-star"></i></span>
                            <span style={{ background: 'rgba(61, 205, 10, 1)', padding: '2px', color: 'rgba(255, 234, 127, 1)'}}><i className="fa fa-star"></i></span>
                          </div>
                        </td>
                        <td><b>$100</b></td>
                        <td><img src="assets/images/green-tick.png" alt="" /></td>
                        <td>
                          <b>
                            <span>Bank Transfer</span><br />
                            <span><img src="assets/images/paypal.png" alt="" /><br /></span>
                            <span>Cheque</span><br />
                          </b>
                        </td>
                        <td><b>Sameday</b></td>
                        <td>
                          <button className="mt-4" style={{background: '#008ED6', borderRadius: '5px', border: '0px', color: '#fff', padding: '7px 3px'}}><b>Sell Now</b></button>
                        </td>
                      </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

      <section className="container outer-section mt-4">
      <div className="container" style={{ backgroundColor: 'rgba(255, 238, 205, 0.50)', borderRadius: '30px' }}>
        <section className="section compare">
          <div className="container">
            <h3 className="text-center pt-3 pb-3 border-left">
              <span>&nbsp; About Us</span>
            </h3>
            <div
              className="inner-cont"
              style={{ backgroundColor: 'rgba(242, 141, 66, 0.4)', padding: '40px', borderRadius: '30px' }}
            >
              <div className="col-xl-12 col-md-12 mx-auto">
                <div className="row mx-auto">
                  <div className="col-xl-12 col-md-6">
                    <div className="inner-box-1">
                      <h6 className='desktop-view' style={{ paddingLeft: '70px' }}><b>Who we do?</b></h6>
                      <h6 className='mobile-view'><b>Who we do?</b></h6>
                      <p className="text-center">
                        Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit <br />
                        interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per <br /> conubia nostra, per inceptos himenaeos.<br />
                        ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,<br /> per inceptos himenaeos.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section compare">
          <div className="container">
            <div
              className="inner-cont"
              style={{ backgroundColor: 'rgb(68, 165, 211, 0.4)', padding: '40px', borderRadius: '30px' }}
            >
              <div className="col-xl-12 col-md-12">
                <div className="row">
                  <div className="col-xl-12 col-md-6">
                    <div className="inner-box-1">
                      <h6 className='desktop-view' style={{ paddingLeft: '70px' }}><b>Who are we?</b></h6>
                      <h6 className='mobile-view'><b>Who are we?</b></h6>
                      <p className="text-center">
                        Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit <br />
                        interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per <br /> conubia nostra, per inceptos himenaeos.<br />
                        ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,<br /> per inceptos himenaeos.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section compare">
          <div className="container">
            <div
              className="inner-cont"
              style={{ backgroundColor: 'rgba(242, 141, 66, 0.4)', padding: '40px', borderRadius: '30px' }}
            >
              <div className="col-xl-12 col-md-1">
                <div className="row">
                  <div className="col-xl-12 col-md-6">
                    <div className="inner-box-1">
                      <h6 className='desktop-view' style={{ paddingLeft: '70px' }}><b>Who are we?</b></h6>
                      <h6 className='mobile-view'><b>Who are we?</b></h6>
                      <p className="text-center">
                        Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit <br />
                        interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per <br /> conubia nostra, per inceptos himenaeos.<br />
                        ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,<br /> per inceptos himenaeos.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
    <div>&nbsp;</div>
    <div className="section">
      <div className="container">
        <div className="inner-cont" style={{ backgroundColor: 'rgba(255, 238, 205, 0.50)', borderRadius: '30px', paddingBottom: '50px' }}>
          <h3 className="text-center pt-3 pb-3 border-left"><span>&nbsp; Frequently Asked Questions</span></h3>
          <div className="col-xl-12 col-md-12 mx-auto">
            <div className="row mx-auto">
              <div className="accordion" id="accordionExample" style={{ backgroundColor: 'inherit' }}>
                {/* Accordion Item 1 */}
                <div className="accordion-item" style={{ backgroundColor: 'inherit' }}>
                  <h2 className="accordion-header" id="headingOne" style={{ backgroundColor: 'inherit' }}>
                    <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne" style={{ backgroundColor: 'inherit', borderBottom: '5px solid #6ECEFF' }}>
                    Why XYZ.com to trade in my phone?
                    </button>
                  </h2>
                  <div id="collapseOne" className="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style={{ backgroundColor: 'inherit' }}>
                    <div className="accordion-body" style={{ backgroundColor: 'inherit' }}>
                      Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit
                      interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per
                      conubia nostra, per inceptos himenaeos.
                      ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,
                      per inceptos himenaeos.
                    </div>
                  </div>
                </div>


                {/* Accordion Item 2 */}
                <div className="accordion-item" style={{ backgroundColor: 'inherit' }}>
                  <h2 className="accordion-header" id="headingTwo" style={{ backgroundColor: 'inherit' }}>
                    <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style={{ backgroundColor: 'inherit', borderBottom: '5px solid #6ECEFF' }}>
                    Why XYZ.com to trade in my phone?
                    </button>
                  </h2>
                  <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample" style={{ backgroundColor: 'inherit' }}>
                    <div className="accordion-body" style={{ backgroundColor: 'inherit' }}>
                      Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit
                      interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per
                      conubia nostra, per inceptos himenaeos.
                      ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,
                      per inceptos himenaeos.
                    </div>
                  </div>
                </div>

                {/* Accordion Item 3 */}
                <div className="accordion-item" style={{ backgroundColor: 'inherit' }}>
                  <h2 className="accordion-header" id="headingThree" style={{ backgroundColor: 'inherit' }}>
                    <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" style={{ backgroundColor: 'inherit', borderBottom: '5px solid #FFB05F' }}>
                    Why XYZ.com to trade in my phone?
                    </button>
                  </h2>
                  <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                    <div className="accordion-body">
                      Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit
                      interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per
                      conubia nostra, per inceptos himenaeos.
                      ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,
                      per inceptos himenaeos.
                    </div>
                  </div>
                </div>



                  {/* Accordion Item 4 */}
                  <div className="accordion-item" style={{ backgroundColor: 'inherit' }}>
                  <h2 className="accordion-header" id="headingFourth" style={{ backgroundColor: 'inherit' }}>
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourth" aria-expanded="false" aria-controls="collapseTwo" style={{ backgroundColor: 'inherit', borderBottom: '5px solid #6ECEFF' }}>
                  Why XYZ.com to trade in my phone?
                  </button>
                  </h2>
                  <div id="collapseFourth" className="accordion-collapse collapse" aria-labelledby="headingFourth" data-bs-parent="#accordionExample" style={{ backgroundColor: 'inherit' }}>
                  <div className="accordion-body" style={{ backgroundColor: 'inherit' }}>
                  Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit
                  interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per
                  conubia nostra, per inceptos himenaeos.
                  ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,
                  per inceptos himenaeos.
                  </div>
                  </div>
                  </div>


                {/* Accordion Item 3 */}
                <div className="accordion-item" style={{ backgroundColor: 'inherit' }}>
                <h2 className="accordion-header" id="headingFifth" style={{ backgroundColor: 'inherit' }}>
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFifth" aria-expanded="false" aria-controls="collapseThree" style={{ backgroundColor: 'inherit', borderBottom: '5px solid #FFB05F' }}>
                Why XYZ.com to trade in my phone?
                </button>
                </h2>
                <div id="collapseFifth" className="accordion-collapse collapse" aria-labelledby="headingFifth" data-bs-parent="#accordionExample">
                <div className="accordion-body">
                Jorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit
                interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per
                conubia nostra, per inceptos himenaeos.
                ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra,
                per inceptos himenaeos.
                </div>
                </div>
                </div>


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<div className='desktop-view'>&nbsp;</div>

      <section className="container outer-section footer-top aos">
      <div className="container" style={{ backgroundColor: 'rgba(0, 142, 214, 0.62)', borderRadius: '30px' }}>
        <footer className="footer">
          <div className="row">
            <div className="col-xl-4 col-md-6">
              <div className="footer-widget footer-menu" style={{ marginTop: '80px' }}>
                <img src="assets/images/footer-logo.png" alt=""  style={{ width: '200px' }} />
              </div>
            </div>
            <div className="col-xl-2 col-md-6">
              <div className="footer-widget footer-menu">
                <h4 className="footer-titles"><b>Quick Links</b></h4>
                <ul>
                  <li><a href="#">About Our Company</a></li>
                  <li><a href="#">Services WE provide</a></li>
                  <li><a href="#">Career & Opportunity</a></li>
                  <li><a href="#">Privacy & policy</a></li>
                  <li><a href="#">Contact US</a></li>
                </ul>
              </div>
            </div>
            <div className="col-xl-2 col-md-6">
              <div className="footer-widget footer-menu">
                <h4 className="footer-titles"><b>Company</b></h4>
                <ul>
                  <li><a href="javascript:;">About Company </a></li>
                  <li><a href="javascript:;">Our Testimonials </a></li>
                  <li><a href="javascript:;">Latest News </a></li>
                  <li><a href="javascript:;">Our mission </a></li>
                  <li><a href="javascript:;">Get a free Quote </a></li>
                </ul>
              </div>
            </div>
            <div className="col-xl-2 col-md-6">
              <div className="footer-widget footer-menu">
                <h4 className="footer-titles"><b>Contact Us</b></h4>
                <ul>
                  <li><a href="#">Sagrada Familia, Herba</a></li>
                  <li><a href="#">Street Front USA</a></li>
                  <li><a href="#">brandoxide@gmail.com</a></li>
                  <li><a href="#">002-568423591</a></li>
                </ul>
              </div>
            </div>
            <div className="col-xl-2 col-md-6">
              <div className="footer-widget footer-menu">
                <h4 className="footer-titles"><b>Follow Us</b></h4>
                <div className="social-icon d-flex">
                  <ul>
                    <li>
                      <a href="#" className="icon" target="_blank">
                        <img src="assets/images/fb.png" alt="" width="30px" height="30px" />
                      </a>
                    </li>
                    <li>
                      <a href="#" className="icon" target="_blank">
                        <img src="assets/images/twitter.png" alt="" width="30px" height="30px" />
                      </a>
                    </li>
                    <li>
                      <a href="#" className="icon" target="_blank">
                        <img src="assets/images/insta.png" alt="" width="30px" height="30px" />
                      </a>
                    </li>
                    <li>
                      <a href="#" className="icon" target="_blank">
                        <img src="assets/images/linkedin.png" alt="" width="30px" height="30px" />
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <hr />
          <p className="mb-0 text-center text-dark pt-10" style={{ color: '#646464' }}>
            Copyright @ 2020 Brandoxide. All rights reserved.
          </p>
        </footer>
      </div>
    </section>
        
        </div>
      );
  
}

export default Devices;